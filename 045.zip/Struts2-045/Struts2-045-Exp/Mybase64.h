#pragma once
char * base64_encode(const unsigned char * bindata, char * base64, int binlength);
void encode(char *srcpPath, char *dstPath);
int base64_decode(const char * base64, unsigned char * bindata);
void decode(char *srcpPath, char *dstPath);
INT BASE64_Decode(const TCHAR* inputBuffer, INT inputCount, BYTE* outputBuffer);