#include "stdafx.h"
#include "Mybase64.h"
const char * base64char = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
char * base64_encode(const unsigned char * bindata, char * base64, int binlength)
{
	int i, j;
	unsigned char current;

	for (i = 0, j = 0; i < binlength; i += 3)
	{
		current = (bindata[i] >> 2);
		current &= (unsigned char)0x3F;
		base64[j++] = base64char[(int)current];

		current = ((unsigned char)(bindata[i] << 4)) & ((unsigned char)0x30);
		if (i + 1 >= binlength)
		{
			base64[j++] = base64char[(int)current];
			base64[j++] = '=';
			base64[j++] = '=';
			break;
		}
		current |= ((unsigned char)(bindata[i + 1] >> 4)) & ((unsigned char)0x0F);
		base64[j++] = base64char[(int)current];

		current = ((unsigned char)(bindata[i + 1] << 2)) & ((unsigned char)0x3C);
		if (i + 2 >= binlength)
		{
			base64[j++] = base64char[(int)current];
			base64[j++] = '=';
			break;
		}
		current |= ((unsigned char)(bindata[i + 2] >> 6)) & ((unsigned char)0x03);
		base64[j++] = base64char[(int)current];

		current = ((unsigned char)bindata[i + 2]) & ((unsigned char)0x3F);
		base64[j++] = base64char[(int)current];
	}
	base64[j] = '\0';
	return base64;
}

void encode(char *srcpPath, char *dstPath)
{
	FILE * fp_in;
	FILE * fp_out;
	fopen_s(&fp_in, srcpPath, "rb");
	fopen_s(&fp_out, dstPath, "w");
	unsigned char bindata[2050];
	char base64[4096];
	size_t bytes;
	while (!feof(fp_in))
	{
		bytes = fread(bindata, 1, 2049, fp_in);
		base64_encode(bindata, base64, bytes);
		fprintf(fp_out, "%s", base64);
	}

	fclose(fp_in);
	fclose(fp_out);
}

//decode base64
int base64_decode(const char * base64, unsigned char * bindata)
{
	int i, j;
	unsigned char k;
	unsigned char temp[4];
	for (i = 0, j = 0; base64[i] != '\0'; i += 4)
	{
		memset(temp, 0xFF, sizeof(temp));
		for (k = 0; k < 64; k++)
		{
			if (base64char[k] == base64[i])
				temp[0] = k;
		}
		for (k = 0; k < 64; k++)
		{
			if (base64char[k] == base64[i + 1])
				temp[1] = k;
		}
		for (k = 0; k < 64; k++)
		{
			if (base64char[k] == base64[i + 2])
				temp[2] = k;
		}
		for (k = 0; k < 64; k++)
		{
			if (base64char[k] == base64[i + 3])
				temp[3] = k;
		}

		bindata[j++] = ((unsigned char)(((unsigned char)(temp[0] << 2)) & 0xFC)) |
			((unsigned char)((unsigned char)(temp[1] >> 4) & 0x03));
		if (base64[i + 2] == '=')
			break;

		bindata[j++] = ((unsigned char)(((unsigned char)(temp[1] << 4)) & 0xF0)) |
			((unsigned char)((unsigned char)(temp[2] >> 2) & 0x0F));
		if (base64[i + 3] == '=')
			break;

		bindata[j++] = ((unsigned char)(((unsigned char)(temp[2] << 6)) & 0xF0)) |
			((unsigned char)(temp[3] & 0x3F));
	}
	return j;
}


//void decode(char *srcpPath, char *dstPath)
//{
//	int i;
//	unsigned char bindata[2050];
//	char base64[4096];
//	size_t bytes;
//	FILE * fp_in;
//	FILE * fp_out;
//	fopen_s(&fp_in, srcpPath, "r");
//	fopen_s(&fp_out, dstPath, "wb");
//
//	while (!feof(fp_in))
//	{
//		for (i = 0; i < 2048; i++)
//		{
//			base64[i] = fgetc(fp_in);
//			if (base64[i] == EOF)
//				break;
//			else if (base64[i] == '\n' || base64[i] == '\r')
//				i--;
//		}
//		bytes = base64_decode(base64, bindata);
//		fwrite(bindata, bytes, 1, fp_out);
//	}
//	fclose(fp_in);
//	fclose(fp_out);
//}


#define B64_EOLN      0xF0  // ����/n
#define B64_CR        0xF1  // �س�/r
#define B64_EOF        0xF2  // ���ַ�-
#define B64_WS        0xE0  // ������߿ո�/t��space��
#define B64_ERROR   0xFF  // �����ַ�
#define B64_NOT_BASE64(a)  (((a)|0x13) == 0xF3)

static const BYTE DATA_ASCII2BIN[128] = {
	0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xE0,0xF0,0xFF,0xFF,0xF1,0xFF,0xFF,
	0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
	0xE0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x3E,0xFF,0xF2,0xFF,0x3F,
	0x34,0x35,0x36,0x37,0x38,0x39,0x3A,0x3B,0x3C,0x3D,0xFF,0xFF,0xFF,0x00,0xFF,0xFF,
	0xFF,0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,
	0x0F,0x10,0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,0x19,0xFF,0xFF,0xFF,0xFF,0xFF,
	0xFF,0x1A,0x1B,0x1C,0x1D,0x1E,0x1F,0x20,0x21,0x22,0x23,0x24,0x25,0x26,0x27,0x28,
	0x29,0x2A,0x2B,0x2C,0x2D,0x2E,0x2F,0x30,0x31,0x32,0x33,0xFF,0xFF,0xFF,0xFF,0xFF
};
INT BASE64_Decode(const TCHAR* inputBuffer, INT inputCount, BYTE* outputBuffer)
{
	INT i, j;
	BYTE b[4];
	TCHAR ch;

	if ((inputBuffer == NULL) || (inputCount < 0))
	{
		return -1;  // ��������
	}

	// ȥ��ͷ���հ��ַ�
	while (inputCount > 0)
	{
		ch = *inputBuffer;
		if ((ch < 0) || (ch >= 0x80))
		{
			return -2;  // ���ݴ��󣬲���ASCII�ַ����뷶Χ��
		}
		else
		{
			if (DATA_ASCII2BIN[ch] == B64_WS)
			{
				inputBuffer++;
				inputCount--;
			}
			else
			{
				break;
			}
		}
	}

	// ȥ��β���Ŀհ��ַ����س������ַ������ַ�
	while (inputCount >= 4)
	{
		ch = inputBuffer[inputCount - 1];
		if ((ch < 0) || (ch >= 0x80))
		{
			return -2;  // ���ݴ��󣬲���ASCII�ַ����뷶Χ��
		}
		else
		{
			if (B64_NOT_BASE64(DATA_ASCII2BIN[ch]))
			{
				inputCount--;
			}
			else
			{
				break;
			}
		}
	}

	// �ַ������ȱ���Ϊ4�ı���
	if ((inputCount % 4) != 0)
	{
		return -2;  // ���ݴ���
	}

	if (outputBuffer != NULL)
	{
		for (i = 0; i < inputCount; i += 4)
		{
			for (j = 0; j < 4; j++)
			{
				ch = *inputBuffer++;
				if ((ch < 0) || (ch >= 0x80))
				{
					return -2;  // ���ݴ��󣬲���ASCII�ַ����뷶Χ��
				}
				else
				{
					if (ch == '=')  // ����BASE64�����е�����ַ�
					{
						break;
					}
					else
					{
						b[j] = DATA_ASCII2BIN[ch];
						if (b[j] & 0x80)
						{
							return -2;  // ���ݴ�����Ч��Base64�����ַ�
						}
					}
				}
			} // End for j

			if (j == 4)
			{
				*outputBuffer++ = (b[0] << 2) | (b[1] >> 4);
				*outputBuffer++ = (b[1] << 4) | (b[2] >> 2);
				*outputBuffer++ = (b[2] << 6) | b[3];
			}
			else if (j == 3)
			{  // ��1������ֽ�
				*outputBuffer++ = (b[0] << 2) | (b[1] >> 4);
				*outputBuffer++ = (b[1] << 4) | (b[2] >> 2);

				return (i >> 2) * 3 + 2;
			}
			else if (j == 2)
			{  // ��2������ֽ�
				*outputBuffer++ = (b[0] << 2) | (b[1] >> 4);

				return (i >> 2) * 3 + 1;
			}
			else
			{
				return -2;  // ���ݴ�����Ч��Base64�����ַ�
			}
		}  // End for i
	}

	return (inputCount >> 2) * 3;
}
void decode(char *srcpPath, char *dstPath)
{
	int i;
	unsigned char bindata[2050];
	char base64[4096];
	size_t bytes;
	FILE * fp_in;
	FILE * fp_out;
	int in_filezie;
	fopen_s(&fp_in, srcpPath, "r");
	fopen_s(&fp_out, dstPath, "wb");
	fseek(fp_in, 0, SEEK_END);
	in_filezie = ftell(fp_in);
	char *pInBuf = (char *)malloc(in_filezie + 1); /* �����ļ���С��̬�����ڴ�ռ� */
	fseek(fp_in, 0L, SEEK_SET); /* ��λ���ļ���ͷ */
	fread(pInBuf, in_filezie, 1, fp_in); /* һ���Զ�ȡȫ���ļ����� */
	pInBuf[in_filezie] = 0;


	int out_len = (in_filezie / 4) * 3;
	out_len += 10;
	BYTE *outBuf = (BYTE*)malloc(out_len);


	BASE64_Decode(pInBuf, in_filezie, outBuf);
	fwrite(outBuf, out_len, 1, fp_out);
	free(outBuf);
	fclose(fp_in);
	fclose(fp_out);
}