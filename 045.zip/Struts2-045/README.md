
#Struts2 S2-045 (CVE-2017-5638) Exp Tools
---
#Exp Function:
-  Command Execute
-  Get Target Website's Physical Path
-  File Upload
-  Getshell
-  Default Webshell For Chopper
-  Support HTTP/HTTPS
-  Support URL With Any Port
-  Note: Default Webshell's Password is s2045@exp

---
Mail: flyteas@gmail.com